# determine_cfr_scope.py

import re
from langchain.chat_models import ChatOpenAI
from langchain.schema import SystemMessage, HumanMessage

def determine_cfr_scope(question: str) -> str:
    """
    Identify all relevant CFR Title(s) and Part(s) from the user's question.
    Return a comma-separated list in the strict format:
      CFR_40_PART_112, CFR_33_PART_154
    or a single item:
      CFR_40_PART_112
    or CFR_UNKNOWN if not identified.

    Example valid outputs:
      - CFR_40_PART_112
      - CFR_40_PART_112, CFR_33_PART_154
      - CFR_UNKNOWN
    """

    system_prompt = (
        "You are an advanced regulatory assistant with deep knowledge of U.S. CFR. "
        "Identify all relevant CFR Title(s) and Part(s) from the user's question. "
        "Return them in comma-separated format (CFR_XX_PART_YY). "
        "If you cannot confidently identify any, respond with 'CFR_UNKNOWN'. "
        "Do not add additional text or explanation."
    )

    user_prompt = (
        f"The user asked: '{question}'.\n\n"
        "Identify all relevant CFR Title/Part pairs. "
        "If multiple, separate them with a comma (CFR_40_PART_112, CFR_33_PART_154). "
        "If unsure, respond with CFR_UNKNOWN."
    )

    llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.5)
    response = llm([
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt)
    ])

    raw_answer = response.content.strip()

    # Regex: One or more 'CFR_<digits>_PART_<digits>' separated by commas
    pattern = re.compile(r'^CFR_\d+_PART_\d+(?:\s*,\s*CFR_\d+_PART_\d+)*$', re.IGNORECASE)

    if pattern.match(raw_answer):
        return raw_answer.upper()
    else:
        return "CFR_UNKNOWN"
