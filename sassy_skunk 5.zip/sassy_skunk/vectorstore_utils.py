# vectorstore_utils.py
import fnmatch
from langchain.vectorstores import Chroma
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.chat_models import ChatOpenAI
from langchain.schema import SystemMessage, HumanMessage

from memory_manager import get_or_create_conversation, SESSION_MEMORY

def answer_with_persistent_chroma(session_id: str, question: str, persist_dir="chroma_db", top_k=2):
    embeddings = OpenAIEmbeddings(model="text-embedding-ada-002")
    vectorstore = Chroma(
        embedding_function=embeddings,
        persist_directory=persist_dir
    )
    retriever = vectorstore.as_retriever(search_kwargs={"k": top_k})

    # 1) Retrieve docs from Chroma
    result = retriever.get_relevant_documents(question)

    # 2) Filter the docs based on cfr_scopes in session memory
    cfr_scopes = SESSION_MEMORY[session_id].get("cfr_scopes", [])
    if cfr_scopes:
        filtered_result = []
        for doc in result:
            doc_title = doc.metadata.get("file_title", "")
            keep_doc = False

            for scope in cfr_scopes:
                # Example scope: "CFR_40_PART_112"
                # We'll remove the "CFR_" prefix -> "40_PART_112"
                # Then match "*40_PART_112*"
                scope_no_prefix = scope.replace("CFR_", "")  # yields "40_PART_112"
                pattern = f"*{scope_no_prefix}*"
                if fnmatch.fnmatch(doc_title, pattern):
                    keep_doc = True
                    break  # Found a match, no need to check further scopes

            if keep_doc:
                filtered_result.append(doc)

        result = filtered_result

    # 3) Build relevant_data from the final filtered docs
    relevant_data = "\n".join(doc.page_content for doc in result)
    if not relevant_data.strip():
        return "I don’t have enough information to answer that.", relevant_data, result

    # 4) Build the prompt for the LLM
    conversation = get_or_create_conversation(session_id)
    conversation_str = "\n".join(
        f"{msg['role'].capitalize()}: {msg['content']}"
        for msg in conversation
    )

    system_msg = SystemMessage(content=(
        "You are ChatGPT, a large language model trained by OpenAI. "
        "Please provide the best possible answer based on the relevant data and the conversation context."
    ))

    user_msg = HumanMessage(content=(
        f"Conversation History:\n{conversation_str}\n\n"
        f"Relevant Data:\n{relevant_data}\n\n"
        f"Question: {question}\n"
        "Answer concisely."
    ))

    llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.1)
    response = llm([system_msg, user_msg])
    direct_answer = response.content.strip()

    return direct_answer, relevant_data, result
