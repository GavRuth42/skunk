import os
import logging
from datetime import datetime
from flask import Flask, request, jsonify

# For shutting down the scheduler on exit
from atexit import register
from apscheduler.schedulers.background import BackgroundScheduler

# Internal modules
from memory_manager import (
    SESSION_MEMORY,
    get_or_create_conversation,
    clear_session,
    append_user_message,
    append_assistant_message,
)
from text_detection import (
    is_thanks,
    is_small_talk,
    get_small_talk_response_llm,
    is_question_vague_in_context,
    is_typo_correction_request,
    correct_typos_llm,
)
from vectorstore_utils import answer_with_persistent_chroma
from summarization import summarize_data_approach1
from requery import requery_for_regulations
from stale_session_cleaner import clear_stale_sessions
from determine_cfr_scope import determine_cfr_scope  # <-- The CFR scope detection module

##############################################################################
# Create Flask app
##############################################################################
app = Flask(__name__)

os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY", "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")

# Configure logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

##############################################################################
# SCHEDULER: Clear stale sessions
##############################################################################
scheduler = BackgroundScheduler()
# For example, every 5 minutes
scheduler.add_job(func=clear_stale_sessions, trigger="interval", minutes=5)
scheduler.start()
register(lambda: scheduler.shutdown())

##############################################################################
# CLEAR MEMORY ENDPOINT
##############################################################################
@app.route("/clear_memory", methods=["POST"])
def clear_memory_endpoint():
    data = request.json or {}
    session_id = data.get("session_id")

    if not session_id:
        return jsonify({"status": "error", "error": "Missing session_id"}), 400

    if session_id in SESSION_MEMORY:
        clear_session(session_id)
        return jsonify({
            "status": "ok",
            "message": f"Cleared session memory for session ID: {session_id}"
        }), 200
    else:
        return jsonify({
            "status": "error",
            "error": f"No session found with ID '{session_id}'"
        }), 404

##############################################################################
# ASK ENDPOINT
##############################################################################
@app.route("/ask", methods=["POST"])
def ask_approach1():
    """
    Approach 1:
      - If wants_details=True => produce a longer answer
      - Otherwise => short summary
    """
    data = request.json or {}
    session_id = data.get("session_id", "global")
    question = data.get("question", "").strip()
    wants_details = data.get("wants_details", False)

    if not question:
        return jsonify({"status": "error", "error": "No question provided."}), 400

    # 1) Ensure session is created so we can safely store data like "cfr_scopes"
    get_or_create_conversation(session_id)

    # 2) Check for trivial question types (thanks, small talk, vague, etc.)
    if is_thanks(question):
        clear_session(session_id)
        return jsonify({
            "status": "ok",
            "answer": "You're welcome! The conversation has ended.",
            "references": [],
            "details": None
        })

    if is_small_talk(question):
        st_response = get_small_talk_response_llm(session_id, question)
        return jsonify({
            "status": "ok",
            "answer": st_response,
            "references": [],
            "details": None
        })

    if is_question_vague_in_context(session_id, question):
        vague_answer = "You might need to add more context."
        return jsonify({
            "status": "ok",
            "answer": vague_answer,
            "references": [],
            "details": None
        })

    if is_typo_correction_request(question):
        append_user_message(session_id, question)
        corrected_text = correct_typos_llm(question)
        answer_msg = f"Here is your corrected text:\n\n{corrected_text}"
        append_assistant_message(session_id, answer_msg)
        return jsonify({
            "status": "ok",
            "answer": answer_msg,
            "references": [],
            "details": None
        })

    # 3) Determine CFR scopes from the question
    cfr_scopes = determine_cfr_scope(question)
    if cfr_scopes == "CFR_UNKNOWN":
        # If unknown, store an empty list => doc filtering won't match anything
        SESSION_MEMORY[session_id]["cfr_scopes"] = []
    else:
        # e.g. cfr_scopes = "CFR_40_PART_112, CFR_33_PART_154"
        scope_list = [scope.strip() for scope in cfr_scopes.split(",")]
        SESSION_MEMORY[session_id]["cfr_scopes"] = scope_list

    # 4) Normal Q&A flow
    append_user_message(session_id, question)

    direct_answer, relevant_data, retrieved_docs = answer_with_persistent_chroma(
        session_id, question, top_k=3
    )

    if not relevant_data.strip() or "I don’t have enough information" in direct_answer:
        fallback = "I don’t have enough information to answer that."
        append_assistant_message(session_id, fallback)
        return jsonify({
            "status": "ok",
            "answer": fallback,
            "references": [],
            "details": None
        })

    # Summarize the relevant data
    detail_level = "long" if wants_details else "short"
    summarized_answer = summarize_data_approach1(relevant_data, question, detail_level=detail_level)

    # Gather heading_keys from docs
    headings_set = set()
    for doc in retrieved_docs:
        if "heading_key" in doc.metadata:
            headings_set.add(doc.metadata["heading_key"])

    # Only display references if detail_level == "long"
    if detail_level == "long" and headings_set:
        summarized_answer += "\n\nReferences::\n"
        for heading_text in headings_set:
            summarized_answer += f"- {heading_text}\n"

    append_assistant_message(session_id, summarized_answer)

    # Optional: parse CFR references in summarized answer
    import re
    cited_references = re.findall(
        r"\(\d+\s?CFR\s\d+\.\d+\(\w+\)\)|\u00a7\s?\d+\.\d+\(\w+\)|\u00a7\s?\d+\.\d+|Section\s\d+\.\d+|"
        r"\d+\s?CFR\s(?:Part\s\d+|\d+\.\d+\(\w+\)|\d+\.\d+)|"
        r"\d+\s?CFR\sAppendix-[A-Za-z0-9-]+(?:\s\d+\.\d+)?",
        summarized_answer
    )
    details = None
    if wants_details and cited_references:
        details = requery_for_regulations(cited_references, question)

    return jsonify({
        "status": "ok",
        "answer": summarized_answer,
        "references": [],
        "details": details
    })

##############################################################################
# HOME
##############################################################################
@app.route("/")
def home():
    return (
        "LLM-based QA\n"
        "POST /ask => short vs. long response (via 'wants_details')\n"
        "POST /clear_memory => clear session memory\n"
    )

##############################################################################
# RUN
##############################################################################
if __name__ == "__main__":
    if not os.getenv("OPENAI_API_KEY"):
        logging.error("OpenAI API key not set. Please set 'OPENAI_API_KEY'.")
        exit(1)
    
    app.run(host="0.0.0.0", port=6000, debug=True)
