import logging
from datetime import datetime, timedelta
from memory_manager import SESSION_MEMORY

def clear_stale_sessions():
    now = datetime.utcnow()
    to_remove = []
    for sid, data in SESSION_MEMORY.items():
        last_updated = data["last_updated"]
        # CHANGED: now any session older than 5 minutes is considered stale
        if (now - last_updated) > timedelta(minutes=5):
            to_remove.append(sid)
    for sid in to_remove:
        logging.debug(f"Session {sid} has been stale for over 5 minutes. Removing.")
        del SESSION_MEMORY[sid]
